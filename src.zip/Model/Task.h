#pragma once
struct Task {
	float Time;
	float Dest;

};
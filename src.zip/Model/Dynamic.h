#pragma once

class Dynamic {
public:
	virtual void Routine(float)= 0;
};
#pragma once
#include <queue>
#
struct Task
{
	float Time; //Amount of seconds to execute task
	float Dest; //Floating point position of destination
};


class Driver
{
	float timeRemaining;
	std::queue<>

};

